# phishing-classifier
this is machine learning project 1



'''pip install -e .  ''' to run setup.py
